// Background Service Worker for SmartFlow Zalo Extension (Manifest V3 - v1.3.0)

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'getData') {
    chrome.storage.local.get(['imei', 'cookies'], function(res) {
      sendResponse({ imei: res.imei || '', cookies: res.cookies || '' });
    });
    return true;
  }
  
  if (request.action === 'fetchCookiesNow') {
    readZaloCookies(function(cookiesJson) {
      sendResponse({ cookies: cookiesJson });
    });
    return true;
  }

  if (request.action === 'extractImeiFromTab') {
    extractImeiFromActiveTab(function(extractedImei) {
      sendResponse({ imei: extractedImei });
    });
    return true;
  }
});

function readZaloCookies(callback) {
  var allCookiesMap = {};
  chrome.cookies.getAll({ domain: 'zalo.me' }, function(c1) {
    (c1 || []).forEach(function(c) { allCookiesMap[c.name] = c.value; });
    chrome.cookies.getAll({ url: 'https://chat.zalo.me' }, function(c2) {
      (c2 || []).forEach(function(c) { allCookiesMap[c.name] = c.value; });
      chrome.cookies.getAll({ url: 'https://wpa.chat.zalo.me' }, function(c3) {
        (c3 || []).forEach(function(c) { allCookiesMap[c.name] = c.value; });
        var jsonStr = JSON.stringify(allCookiesMap);
        if (Object.keys(allCookiesMap).length > 0) {
          chrome.storage.local.set({ cookies: jsonStr });
        }
        if (callback) callback(jsonStr);
      });
    });
  });
}

function extractImeiFromActiveTab(callback) {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (!tabs || !tabs[0] || !tabs[0].url || !tabs[0].url.includes('zalo.me')) {
      if (callback) callback('');
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => {
        try {
          for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (k && (k.toLowerCase().includes('imei') || k === 'z_imei')) {
              const val = localStorage.getItem(k);
              if (val && val.length > 20) return val;
            }
          }
        } catch (e) {}
        return '';
      }
    }).then(results => {
      const found = results && results[0] && results[0].result ? results[0].result : '';
      if (found) {
        chrome.storage.local.set({ imei: found });
      }
      if (callback) callback(found);
    }).catch(() => {
      if (callback) callback('');
    });
  });
}

// B?t m?i request c? ch?a imei= khi Zalo Web ho?t ??ng
chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    var url = details.url || '';
    if (url.includes('imei=')) {
      try {
        var urlObj = new URL(url);
        var imei = urlObj.searchParams.get('imei') || '';
        if (imei && imei.length > 15) {
          chrome.storage.local.set({ imei: imei });
          chrome.runtime.sendMessage({ action: 'IMEIValue', imei: imei }).catch(function() {});
          readZaloCookies(function(cJson) {
            chrome.runtime.sendMessage({ action: 'CookiesValue', cookies: cJson }).catch(function() {});
          });
        }
      } catch (e) {}
    }
  },
  { urls: ["*://*.zalo.me/*"] }
);

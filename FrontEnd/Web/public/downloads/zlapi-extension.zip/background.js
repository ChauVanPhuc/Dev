// Background Service Worker for SmartFlow Zalo Extension (Manifest V3)

// Lắng nghe yêu cầu lấy dữ liệu lưu trong bộ đệm khi popup mở
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'getData') {
    chrome.storage.local.get(['imei', 'cookies'], function(res) {
      sendResponse({ imei: res.imei || '', cookies: res.cookies || '' });
    });
    return true; // Giữ kênh async
  }
  
  if (request.action === 'fetchCookiesNow') {
    readZaloCookies(function(cookiesJson) {
      sendResponse({ cookies: cookiesJson });
    });
    return true;
  }
});

// Hàm đọc cookies Zalo trực tiếp
function readZaloCookies(callback) {
  chrome.cookies.getAll({ domain: 'zalo.me' }, function(cookies) {
    if (!cookies || cookies.length === 0) {
      chrome.cookies.getAll({ url: 'https://chat.zalo.me' }, function(altCookies) {
        processCookies(altCookies || [], callback);
      });
    } else {
      processCookies(cookies, callback);
    }
  });
}

function processCookies(cookiesList, callback) {
  var cookiesDict = {};
  for (var i = 0; i < cookiesList.length; i++) {
    cookiesDict[cookiesList[i].name] = cookiesList[i].value;
  }
  var jsonStr = JSON.stringify(cookiesDict);
  if (Object.keys(cookiesDict).length > 0) {
    chrome.storage.local.set({ cookies: jsonStr });
  }
  if (callback) callback(jsonStr);
}

// Bắt request getServerInfo để trích xuất IMEI khi Zalo đăng nhập / tải trang
chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    var url = details.url || '';
    if (url.includes('/api/login/getServerInfo') && url.includes('imei=')) {
      try {
        var urlObj = new URL(url);
        var imei = urlObj.searchParams.get('imei') || '';
        if (imei) {
          chrome.storage.local.set({ imei: imei });
          // Thử gửi thông điệp tới popup nếu đang mở
          chrome.runtime.sendMessage({ action: 'IMEIValue', imei: imei }).catch(function() {});
          
          // Đọc kèm cookies
          readZaloCookies(function(cJson) {
            chrome.runtime.sendMessage({ action: 'CookiesValue', cookies: cJson }).catch(function() {});
          });
        }
      } catch (e) {
        console.error('Lỗi phân tích IMEI:', e);
      }
    }
  },
  { urls: ["*://*.zalo.me/*"] }
);
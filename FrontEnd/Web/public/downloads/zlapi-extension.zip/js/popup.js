// Popup script for SmartFlow Zalo Extension (Manifest V3)

document.addEventListener('DOMContentLoaded', function() {
  // 1. ??c t? chrome.storage.local
  chrome.storage.local.get(['imei', 'cookies'], function(res) {
    if (res.imei) applyImei(res.imei);
    if (res.cookies) applyCookies(res.cookies);

    // Lu?n refresh cookies m?i nh?t t? Zalo
    chrome.runtime.sendMessage({ action: 'fetchCookiesNow' }, function(cRes) {
      if (cRes && cRes.cookies) applyCookies(cRes.cookies);
      checkLoginStatus();
    });

    // Th? tr?ch xu?t IMEI t? tab ?ang m? n?u ch?a c?
    if (!res.imei) {
      chrome.runtime.sendMessage({ action: 'extractImeiFromTab' }, function(iRes) {
        if (iRes && iRes.imei) applyImei(iRes.imei);
        updateSyncButtonState();
      });
    }

    updateSyncButtonState();
  });

  chrome.storage.onChanged.addListener(function(changes) {
    if (changes.imei && changes.imei.newValue) applyImei(changes.imei.newValue);
    if (changes.cookies && changes.cookies.newValue) applyCookies(changes.cookies.newValue);
    updateSyncButtonState();
  });
});

function applyImei(imeiVal) {
  var imeiDiv = document.getElementById('imei-div');
  var imeiInput = document.getElementById('imei-input');
  if (imeiDiv && imeiInput) {
    imeiDiv.classList.remove('is-disabled');
    imeiInput.value = imeiVal;
  }
}

function applyCookies(cookiesVal) {
  var cookiesDiv = document.getElementById('cookies-div');
  var cookiesInput = document.getElementById('cookies-input');
  if (cookiesDiv && cookiesInput) {
    cookiesDiv.classList.remove('is-disabled');
    cookiesInput.value = cookiesVal;
  }
}

function checkLoginStatus() {
  var cookiesInput = document.getElementById('cookies-input');
  var statusMsg = document.getElementById('sync-status');
  if (cookiesInput && cookiesInput.value) {
    try {
      var cObj = JSON.parse(cookiesInput.value);
      if (!cObj.zpw_sek && !cObj.zlogin_session) {
        if (statusMsg) {
          statusMsg.innerHTML = '<span style="color: #D97706; font-size: 11px;">?? B?n ch?a ??ng nh?p Zalo Web. Vui l?ng qu?t m? QR ??ng nh?p tab b?n c?nh!</span>';
        }
      }
    } catch(e) {}
  }
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'IMEIValue' && request.imei) {
    applyImei(request.imei);
    updateSyncButtonState();
  } else if (request.action === 'CookiesValue' && request.cookies) {
    applyCookies(request.cookies);
    updateSyncButtonState();
    checkLoginStatus();
  }
});

function updateSyncButtonState() {
  var imei = document.getElementById('imei-input') ? document.getElementById('imei-input').value : '';
  var cookies = document.getElementById('cookies-input') ? document.getElementById('cookies-input').value : '';
  var btnSync = document.getElementById('btn-sync-smartflow');
  if (btnSync) {
    if (imei && cookies) {
      btnSync.removeAttribute('disabled');
      btnSync.style.opacity = '1';
      btnSync.style.cursor = 'pointer';
    } else {
      btnSync.setAttribute('disabled', 'disabled');
      btnSync.style.opacity = '0.6';
      btnSync.style.cursor = 'not-allowed';
    }
  }
}

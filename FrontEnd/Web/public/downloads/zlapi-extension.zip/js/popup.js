// Popup script for SmartFlow Zalo Extension (Manifest V3)

document.addEventListener('DOMContentLoaded', function() {
  // 1. Đọc ngay từ chrome.storage.local khi popup mở
  chrome.storage.local.get(['imei', 'cookies'], function(res) {
    if (res.imei) {
      applyImei(res.imei);
    }
    if (res.cookies) {
      applyCookies(res.cookies);
    } else {
      // Thử đọc cookies trực tiếp từ background nếu đã đăng nhập chat.zalo.me
      chrome.runtime.sendMessage({ action: 'fetchCookiesNow' }, function(cRes) {
        if (cRes && cRes.cookies) {
          applyCookies(cRes.cookies);
        }
      });
    }
    updateSyncButtonState();
  });

  // 2. Lắng nghe thay đổi trong storage
  chrome.storage.onChanged.addListener(function(changes) {
    if (changes.imei && changes.imei.newValue) {
      applyImei(changes.imei.newValue);
    }
    if (changes.cookies && changes.cookies.newValue) {
      applyCookies(changes.cookies.newValue);
    }
    updateSyncButtonState();
  });
});

function applyImei(imeiVal) {
  var imeiDiv = document.getElementById('imei-div');
  var imeiInput = document.getElementById('imei-input');
  if (imeiDiv && imeiInput) {
    imeiDiv.classList.remove('is-disabled');
    imeiInput.value = imeiVal;
  }
}

function applyCookies(cookiesVal) {
  var cookiesDiv = document.getElementById('cookies-div');
  var cookiesInput = document.getElementById('cookies-input');
  if (cookiesDiv && cookiesInput) {
    cookiesDiv.classList.remove('is-disabled');
    cookiesInput.value = cookiesVal;
  }
}

// 3. Lắng nghe thông điệp trực tiếp từ background
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'IMEIValue' && request.imei) {
    applyImei(request.imei);
    updateSyncButtonState();
  } else if (request.action === 'CookiesValue' && request.cookies) {
    applyCookies(request.cookies);
    updateSyncButtonState();
  }
});

function updateSyncButtonState() {
  var imei = document.getElementById('imei-input') ? document.getElementById('imei-input').value : '';
  var cookies = document.getElementById('cookies-input') ? document.getElementById('cookies-input').value : '';
  var btnSync = document.getElementById('btn-sync-smartflow');
  if (btnSync) {
    if (imei && cookies) {
      btnSync.removeAttribute('disabled');
      btnSync.style.opacity = '1';
      btnSync.style.cursor = 'pointer';
    } else {
      btnSync.setAttribute('disabled', 'disabled');
      btnSync.style.opacity = '0.6';
      btnSync.style.cursor = 'not-allowed';
    }
  }
}
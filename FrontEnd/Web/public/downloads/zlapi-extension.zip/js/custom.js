function copyTextToClipboard(str) {
  const el = document.createElement('textarea');
  el.value = str;
  el.setAttribute('readonly', '');
  el.style.position = 'absolute';
  el.style.left = '-9999px';
  document.body.appendChild(el);
  el.select();
  document.execCommand('copy');
  document.body.removeChild(el);
}

// Copy IMEI
document.getElementById('btn-copy-1').addEventListener('click', async () => {
  var textInput = document.getElementById("imei-input");
  if (!textInput.value) return;

  copyTextToClipboard(textInput.value);

  let btnCopy = document.getElementById('btn-copy-1');
  btnCopy.innerText = "✓";
  setTimeout(() => {
    btnCopy.innerHTML = `<i class="el-icon-document-copy"></i>`;
  }, 1500);
});

// Copy Cookies
document.getElementById('btn-copy-2').addEventListener('click', async () => {
  var textInput = document.getElementById("cookies-input");
  if (!textInput.value) return;

  copyTextToClipboard(textInput.value);

  let btnCopy = document.getElementById('btn-copy-2');
  btnCopy.innerText = "✓";
  setTimeout(() => {
    btnCopy.innerHTML = `<i class="el-icon-document-copy"></i>`;
  }, 1500);
});

// Refresh tab
document.addEventListener("DOMContentLoaded", function() {
  var refBtn = document.getElementById("refresh-button");
  if (refBtn) {
    refBtn.addEventListener("click", function() {
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs && tabs[0]) {
          chrome.tabs.reload(tabs[0].id);
        }
      });
    });
  }
});

// ⚡ 1-Click Sync to SmartFlow ERP
document.getElementById('btn-sync-smartflow').addEventListener('click', async () => {
  const imei = document.getElementById("imei-input") ? document.getElementById("imei-input").value : '';
  const cookies = document.getElementById("cookies-input") ? document.getElementById("cookies-input").value : '';
  const statusMsg = document.getElementById("sync-status");
  const btn = document.getElementById('btn-sync-smartflow');

  if (!imei || !cookies) {
    alert("Chưa có đủ thông tin IMEI & Cookies! Vui lòng mở chat.zalo.me và đăng nhập.");
    return;
  }

  btn.setAttribute('disabled', 'disabled');
  btn.innerText = "⏳ Đang gửi dữ liệu lên SmartFlow...";
  if (statusMsg) statusMsg.innerHTML = '<span style="color: #6B7280;">Đang kết nối API SmartFlow...</span>';

  // Thử gửi qua server cloud hoặc localhost nếu có
  const targetEndpoints = [
    'https://api.smartflowg7.cloud/api/v1/lpn-crawler/zalo/config',
    'http://localhost:8000/api/v1/lpn-crawler/zalo/config'
  ];

  let success = false;
  let lastError = null;

  for (const endpoint of targetEndpoints) {
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imei: imei,
          session_cookies: cookies
        })
      });
      if (res.ok) {
        success = true;
        break;
      }
    } catch (e) {
      lastError = e;
    }
  }

  if (success) {
    btn.innerText = "✓ Đã đồng bộ thành công!";
    btn.style.backgroundColor = "#10B981";
    if (statusMsg) statusMsg.innerHTML = '<span style="color:#059669; font-weight:bold;">✓ Đã lưu IMEI & Cookies vào SmartFlow ERP!</span>';
  } else {
    btn.innerText = "✕ Không thể đồng bộ tự động";
    btn.style.backgroundColor = "#EF4444";
    if (statusMsg) statusMsg.innerHTML = '<span style="color:#DC2626;">Vui lòng dùng nút Copy và dán thủ công vào SmartFlow!</span>';
  }

  setTimeout(() => {
    btn.removeAttribute('disabled');
    btn.innerText = "⚡ Đồng bộ 1-Click lên SmartFlow ERP";
    btn.style.backgroundColor = "#7B5233";
  }, 4000);
});
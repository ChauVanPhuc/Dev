function copyTextToClipboard(str) {
  const el = document.createElement('textarea');
  el.value = str;
  el.setAttribute('readonly', '');
  el.style.position = 'absolute';
  el.style.left = '-9999px';
  document.body.appendChild(el);
  el.select();
  document.execCommand('copy');
  document.body.removeChild(el);
}

// Copy IMEI
document.getElementById('btn-copy-1').addEventListener('click', async () => {
  var textInput = document.getElementById("imei-input");
  if (!textInput.value) return;
  copyTextToClipboard(textInput.value);
  let btnCopy = document.getElementById('btn-copy-1');
  btnCopy.innerText = "?";
  setTimeout(() => { btnCopy.innerHTML = `<i class="el-icon-document-copy"></i>`; }, 1500);
});

// Copy Cookies
document.getElementById('btn-copy-2').addEventListener('click', async () => {
  var textInput = document.getElementById("cookies-input");
  if (!textInput.value) return;
  copyTextToClipboard(textInput.value);
  let btnCopy = document.getElementById('btn-copy-2');
  btnCopy.innerText = "?";
  setTimeout(() => { btnCopy.innerHTML = `<i class="el-icon-document-copy"></i>`; }, 1500);
});

// Refresh tab
document.addEventListener("DOMContentLoaded", function() {
  var refBtn = document.getElementById("refresh-button");
  if (refBtn) {
    refBtn.addEventListener("click", function() {
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs && tabs[0]) {
          chrome.tabs.reload(tabs[0].id);
        }
      });
    });
  }
});

// ? 1-Click Sync to SmartFlow ERP
document.getElementById('btn-sync-smartflow').addEventListener('click', async () => {
  const imei = document.getElementById("imei-input") ? document.getElementById("imei-input").value : '';
  const cookies = document.getElementById("cookies-input") ? document.getElementById("cookies-input").value : '';
  const statusMsg = document.getElementById("sync-status");
  const btn = document.getElementById('btn-sync-smartflow');

  if (!imei || !cookies) {
    alert("Ch?a c? ?? th?ng tin IMEI & Cookies! Vui l?ng m? chat.zalo.me v? ??ng nh?p.");
    return;
  }

  // Ki?m tra s? b? cookie xem c? zpw_sek hay kh?ng
  try {
    const cObj = JSON.parse(cookies);
    if (!cObj.zpw_sek && !cObj.zlogin_session) {
      if (statusMsg) {
        statusMsg.innerHTML = '<span style="color:#DC2626; font-weight:bold;">?? Ch?a t?m th?y phi?n ??ng nh?p Zalo (thi?u zpw_sek). Vui l?ng ??ng nh?p Zalo tr??c!</span>';
      }
    }
  } catch(e) {}

  btn.setAttribute('disabled', 'disabled');
  btn.innerText = "? ?ang k?t n?i m?y ch? SmartFlow...";
  if (statusMsg) statusMsg.innerHTML = '<span style="color: #6B7280;">?ang ki?m tra k?t n?i API...</span>';

  const targetEndpoints = [
    'https://smartflowg7.cloud/api/v1/lpn-crawler/zalo/config',
    'https://dashboard.smartflowg7.cloud/api/v1/lpn-crawler/zalo/config',
    'https://smartflowq7.cloud/api/v1/lpn-crawler/zalo/config',
    'http://localhost:8000/api/v1/lpn-crawler/zalo/config',
    'http://127.0.0.1:8000/api/v1/lpn-crawler/zalo/config'
  ];

  let success = false;
  let isConnected = false;
  let feedbackMessage = "";
  let detailError = "";

  for (const endpoint of targetEndpoints) {
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Extension-Key": "SmartFlowZaloExt2026"
        },
        body: JSON.stringify({
          imei: imei,
          session_cookies: cookies
        })
      });
      if (res.ok) {
        const resData = await res.json().catch(() => ({}));
        success = true;
        isConnected = !!resData.is_connected;
        feedbackMessage = resData.message || (isConnected ? "K?t n?i Zalo Bot th?nh c?ng!" : "?? l?u c?u h?nh!");
        break;
      } else {
        const errJson = await res.json().catch(() => ({}));
        detailError = errJson.detail || errJson.message || `HTTP ${res.status}`;
      }
    } catch (e) {
      detailError = e.message || String(e);
    }
  }

  if (success) {
    if (isConnected) {
      btn.innerText = "? K?t n?i Zalo Bot Th?nh C?ng!";
      btn.style.backgroundColor = "#10B981";
      if (statusMsg) statusMsg.innerHTML = '<span style="color:#059669; font-weight:bold;">? ' + feedbackMessage + '</span>';
    } else {
      btn.innerText = "?? ?? l?u nh?ng Zalo Bot Offline";
      btn.style.backgroundColor = "#F59E0B";
      if (statusMsg) statusMsg.innerHTML = '<span style="color:#D97706; font-weight:bold;">?? ' + feedbackMessage + '</span>';
    }
  } else {
    btn.innerText = "? Kh?ng th? ??ng b? t? ??ng";
    btn.style.backgroundColor = "#EF4444";
    if (statusMsg) statusMsg.innerHTML = '<span style="color:#DC2626; font-weight:bold;">L?i: ' + (detailError || "Kh?ng k?t n?i ???c server SmartFlow") + '</span>';
  }

  setTimeout(() => {
    btn.removeAttribute('disabled');
    btn.innerText = "? ??ng b? 1-Click l?n SmartFlow ERP";
    btn.style.backgroundColor = "#7B5233";
  }, 4500);
});
